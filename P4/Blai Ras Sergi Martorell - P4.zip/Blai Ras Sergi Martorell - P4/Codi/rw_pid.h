//autors --> Sergi Martorell Tello i Blai Ras Jimenez

#ifndef RW_PID_H_   /* Include guard */
#define RW_PID_H_

void write_fitxer(char nomFitxer[20],int pid);  /* An example function declaration */
int read_fitxer(char nomFitxer[20]);
#endif // RW_PID_H_
