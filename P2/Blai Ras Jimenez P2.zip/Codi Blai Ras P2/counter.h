

int countWords(char *sentence); //counts the number of words in sentence

int countOccurrences(char *sentence, char ch); //counts the number of ocurrences of character ch in sentence